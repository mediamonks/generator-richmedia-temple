import Banner from "./Banner";
import config from "../.richmediarc";

const banner = new Banner(config);
banner.start();
