*MEDIAMONKS SOURCE FILES*
These files are build with a framework. In order to make changes you need to use the framework.
Go to https://assets-at-scale.gitbook.io/temple-suite/adjust-a-banner-step-by-step for more information